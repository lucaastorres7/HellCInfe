# HellCInfe
Projeto para a cadeira de Introdução à Programação dos estudantes do CIN-UFPE.

## Run project

```
python src/main.py
```